import machine
import network
import urequests
import ntptime
from time import localtime, sleep
from ili9341 import Display
from machine import Pin, SPI
from xglcd_font import XglcdFont

#wifi
wifi = network.WLAN(network.STA_IF)
wifi.active(True)
wifi.connect('Wokwi-GUEST', '')
print("Connected to WiFi:", wifi.ifconfig())

#api
API_KEY = ''
CITY = 'Dubai'
WEATHER_URL = f'http://api.openweathermap.org/data/2.5/weather?q={CITY}&appid={API_KEY}&units=metric'

#screen
spi = SPI(1, baudrate=40000000, mosi=Pin(23), miso=Pin(19), sck=Pin(18))
display = Display(spi, cs=Pin(5), dc=Pin(33), rst=Pin(32))
font = XglcdFont('Wendy7x8.c', 7, 8)

#weather data
def get_weather():
    try:
        response = urequests.get(WEATHER_URL)
        data = response.json()
        response.close()
        weather = {
            'temp': data['main']['temp'],
            'description': data['weather'][0]['description'].capitalize()
        }
        return weather
    except Exception as e:
        print("Error fetching weather data:", e)
        return {'temp': 'N/A', 'description': 'N/A'}

#time
def sync_time():
    try:
        ntptime.settime()
        print("Time synchronized")
    except Exception as e:
        print("Error synchronizing time:", e)

# Display on screen
def display_time_and_weather():
    display.clear()
    while True:
        current_time = localtime()
        time_str = "{:02}:{:02}:{:02}".format(current_time[3], current_time[4], current_time[5])
        date_str = "{:02}/{:02}/{:04}".format(current_time[2], current_time[1], current_time[0])

        weather = get_weather()
        temp = weather['temp']
        description = weather['description']

        display.clear()
        display.draw_text(10, 10, "Time:", font, color=0xFFFF)
        display.draw_text(10, 30, time_str, font, color=0xFFFF)
        display.draw_text(10, 50, "Date:", font, color=0xFFFF)
        display.draw_text(10, 70, date_str, font, color=0xFFFF)
        display.draw_text(10, 90, "Temp:", font, color=0xFFFF)
        display.draw_text(10, 110, f"{temp}C", font, color=0xFFFF)
        display.draw_text(10, 130, "Desc:", font, color=0xFFFF)
        display.draw_text(10, 150, description, font, color=0xFFFF)

        sleep(60)

#main
def main():
    connect_to_wifi()
    sync_time()
    display_time_and_weather()

if __name__ == '__main__':
    main()
